import 'package:flutter/material.dart';

class MyList extends StatelessWidget {
  const MyList({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "My List",
            style: TextStyle(
                fontWeight: FontWeight.bold, color: Colors.white, fontSize: 20),
          ),
          SizedBox(
            width: double.infinity,
            height: 100,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  Container(
                    width: 65,
                    height: 500,
                    decoration: const BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage("assets/witcher.jpg"),
                        fit: BoxFit.contain,
                      ),
                      shape: BoxShape.rectangle,
                    ),
                  ),
                  Container(
                    width: 65,
                    height: 500,
                    decoration: const BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage("assets/carole.jpg"),
                        fit: BoxFit.contain,
                      ),
                      shape: BoxShape.rectangle,
                    ),
                  ),
                  Container(
                    width: 65,
                    height: 500,
                    decoration: const BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage("assets/black_mirror.jpg"),
                        fit: BoxFit.contain,
                      ),
                      shape: BoxShape.rectangle,
                    ),
                  ),
                  Container(
                    width: 65,
                    height: 500,
                    decoration: const BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage("assets/umbrella_academy.jpg"),
                        fit: BoxFit.contain,
                      ),
                      shape: BoxShape.rectangle,
                    ),
                  ),
                  Container(
                    width: 65,
                    height: 500,
                    decoration: const BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage("assets/violet_evergarden.jpg"),
                        fit: BoxFit.contain,
                      ),
                      shape: BoxShape.rectangle,
                    ),
                  ),
                  Container(
                    width: 65,
                    height: 500,
                    decoration: const BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage("assets/sintel.jpg"),
                        fit: BoxFit.contain,
                      ),
                      shape: BoxShape.rectangle,
                    ),
                  ),
                  Container(
                    width: 65,
                    height: 500,
                    decoration: const BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage("assets/witcher.jpg"),
                        fit: BoxFit.contain,
                      ),
                      shape: BoxShape.rectangle,
                    ),
                  ),
                  Container(
                    width: 65,
                    height: 500,
                    decoration: const BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage("assets/carole.jpg"),
                        fit: BoxFit.contain,
                      ),
                      shape: BoxShape.rectangle,
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
