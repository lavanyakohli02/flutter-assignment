import 'package:flutter/material.dart';

class IndMovie extends StatelessWidget {
  const IndMovie({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Indian Movies",
            style: TextStyle(
                fontSize: 30, fontWeight: FontWeight.bold, color: Colors.white),
          ),
          SizedBox(
            width: double.infinity,
            height: 200,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: const [
                SizedBox(
                  width: 100,
                  height: 400,
                  child: Image(
                    image: AssetImage("assets\bollywood1.jpg"),
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(
                  width: 100,
                  height: 400,
                  child: Image(
                    image: AssetImage("assets\bollywood1.jpg"),
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(
                  width: 100,
                  height: 400,
                  child: Image(
                    image: AssetImage("assets\bollywood1.jpg"),
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(
                  width: 100,
                  height: 400,
                  child: Image(
                    image: AssetImage("assets\bollywood2.jpg"),
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(
                  width: 100,
                  height: 400,
                  child: Image(
                    image: AssetImage("assets\bollywood3.jpg"),
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(
                  width: 100,
                  height: 400,
                  child: Image(
                    image: AssetImage("assets\bollywood4.jpg"),
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(
                  width: 100,
                  height: 400,
                  child: Image(
                    image: AssetImage("assets\bollywood5.jpg"),
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(
                  width: 100,
                  height: 400,
                  child: Image(
                    image: AssetImage("assets\bollywood6.jpg"),
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(
                  width: 100,
                  height: 400,
                  child: Image(
                    image: AssetImage("assets\bollywood7.jpg"),
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(
                  width: 100,
                  height: 400,
                  child: Image(
                    image: AssetImage("assets\bollywood9.jpg"),
                    fit: BoxFit.cover,
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
