import 'package:flutter/material.dart';

class NF_ORIGNAL extends StatelessWidget {
  const NF_ORIGNAL({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Netflix Orignal",
            style: TextStyle(
                fontWeight: FontWeight.bold, color: Colors.white, fontSize: 20),
          ),
          SizedBox(
            width: double.infinity,
            height: 100,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: const [
                SizedBox(
                  width: 80,
                  height: 200,
                  child: Image(
                    image: AssetImage("orignal (1).jpeg"),
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(
                  width: 80,
                  height: 200,
                  child: Image(
                    image: AssetImage("orignal (2).jpeg"),
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(
                  width: 80,
                  height: 200,
                  child: Image(
                    image: AssetImage("orignal (3).jpeg"),
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(
                  width: 80,
                  height: 200,
                  child: Image(
                    image: AssetImage("orignal (4).jpeg"),
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(
                  width: 80,
                  height: 200,
                  child: Image(
                    image: AssetImage("orignal (5).jpeg"),
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(
                  width: 80,
                  height: 200,
                  child: Image(
                    image: AssetImage("orignal (6).jpeg"),
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(
                  width: 80,
                  height: 200,
                  child: Image(
                    image: AssetImage("orignal (7).jpeg"),
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(
                  width: 80,
                  height: 200,
                  child: Image(
                    image: AssetImage("orignal (8).jpeg"),
                    fit: BoxFit.cover,
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
