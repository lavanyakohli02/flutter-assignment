import 'package:flutter/material.dart';

class PREVIEW extends StatelessWidget {
  const PREVIEW({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Previews",
            style: TextStyle(
                color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
          ),
          SizedBox(
            width: double.infinity,
            height: 100,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: const [
                CircleAvatar(
                  backgroundImage: AssetImage("assets/stranger_things.jpg"),
                  radius: 50,
                ),
                CircleAvatar(
                  backgroundImage: AssetImage("assets/dogs.jpg"),
                  radius: 50,
                ),
                CircleAvatar(
                  backgroundImage: AssetImage("assets/sintel.jpg"),
                  radius: 50,
                ),
                CircleAvatar(
                  backgroundImage: AssetImage("assets/thirteen_reasons.jpg"),
                  radius: 50,
                ),
                CircleAvatar(
                  backgroundImage: AssetImage("assets/orignal (3).jpeg"),
                  radius: 50,
                ),
                CircleAvatar(
                  backgroundImage: AssetImage("assets/orignal (5).jpeg"),
                  radius: 50,
                ),
                CircleAvatar(
                  backgroundImage: AssetImage("assets/orignal (8).jpeg"),
                  radius: 50,
                ),
                CircleAvatar(
                  backgroundImage: AssetImage("assets/OFFICIAL.png"),
                  radius: 50,
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
