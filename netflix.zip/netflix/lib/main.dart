import 'package:flutter/material.dart';
import 'package:netflixx/screen/bottomNav.dart';

void main() {
  runApp(const MaterialApp(
    //home:HomePage()
    home: NavBar(),
    debugShowCheckedModeBanner: false,
  ));
}
