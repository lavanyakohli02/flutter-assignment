// ignore_for_file: file_names

import 'package:flutter/material.dart';
import 'package:netflixx/screen/comingSoon.dart';
import 'package:netflixx/screen/downloads.dart';
import 'package:netflixx/screen/home_Page.dart';
import 'package:netflixx/screen/more.dart';
import 'package:netflixx/screen/search.dart';

class NavBar extends StatefulWidget {
  const NavBar({super.key});

  @override
  State<NavBar> createState() => _NavBarState();
}

class _NavBarState extends State<NavBar> {
  int currentIndexs = 0;
  final List screens = [
    const HomePage(),
    const Search(),
    const ComingSoon(),
    const Download(),
    const More(),
  ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: Colors.black,
            appBar: AppBar(
              backgroundColor: Colors.black,
              leading: Image.asset("assets/netflix_logo0.png"),
              actions: [
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: GestureDetector(
                      onTap: () {},
                      child: const Text(
                        "TV Shows",
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold),
                      )),
                ),
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: GestureDetector(
                      onTap: () {},
                      child: const Text("Movies",
                          style: TextStyle(
                              fontSize: 18, fontWeight: FontWeight.bold))),
                ),
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: GestureDetector(
                      onTap: () {},
                      child: const Text("My List",
                          style: TextStyle(
                              fontSize: 18, fontWeight: FontWeight.bold))),
                )
              ],
            ),
            body: screens[currentIndexs],
            bottomNavigationBar: BottomNavigationBar(
              currentIndex: currentIndexs,
              type: BottomNavigationBarType.fixed,
              onTap: (value) {
                setState(() {
                  currentIndexs = value;
                });
              },
              backgroundColor: Colors.black,
              selectedItemColor: Colors.white,
              unselectedItemColor: Colors.white.withOpacity(.60),
              selectedFontSize: 13,
              unselectedFontSize: 10,
              items: const [
                BottomNavigationBarItem(label: "Home", icon: Icon(Icons.home)),
                BottomNavigationBarItem(
                    label: "Search", icon: Icon(Icons.search)),
                BottomNavigationBarItem(
                    label: "ComingSoon",
                    icon: Icon(Icons.ondemand_video_sharp)),
                BottomNavigationBarItem(
                    label: "Download", icon: Icon(Icons.download)),
                BottomNavigationBarItem(
                    label: "More", icon: Icon(Icons.more_vert))
              ],
            )));
  }
}
