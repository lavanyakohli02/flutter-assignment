import 'package:flutter/material.dart';

class More extends StatefulWidget {
  const More({super.key});

  @override
  State<More> createState() => _MoreState();
}

class _MoreState extends State<More> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.black,
          leading: const Icon(
            Icons.arrow_back,
            color: Colors.grey,
          ),
          title: const Text(
            "Profiles & More",
            style: TextStyle(
                fontWeight: FontWeight.bold, color: Colors.white, fontSize: 20),
          ),
        ),
        body: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: double.infinity,
                  height: 200,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      Column(
                        children: [
                          Container(
                            height: 100,
                            width: 150,
                            decoration: BoxDecoration(
                                image: const DecorationImage(
                                  image: AssetImage("user.png"),
                                  fit: BoxFit.contain,
                                ),
                                shape: BoxShape.circle,
                                border:
                                    Border.all(color: Colors.white, width: 4)),
                          ),
                          const SizedBox(height: 8),
                          const Text("User#1",
                              style: TextStyle(color: Colors.grey))
                        ],
                      ),
                      Column(
                        children: [
                          Container(
                            height: 100,
                            width: 150,
                            decoration: BoxDecoration(
                                image: const DecorationImage(
                                  image: AssetImage("user.png"),
                                  fit: BoxFit.contain,
                                ),
                                shape: BoxShape.circle,
                                border:
                                    Border.all(color: Colors.white, width: 4)),
                          ),
                          const SizedBox(height: 8),
                          const Text("User#2",
                              style: TextStyle(color: Colors.grey))
                        ],
                      ),
                      Column(
                        children: [
                          Container(
                            height: 100,
                            width: 150,
                            decoration: BoxDecoration(
                                image: const DecorationImage(
                                  image: AssetImage("user.png"),
                                  fit: BoxFit.contain,
                                ),
                                shape: BoxShape.circle,
                                border:
                                    Border.all(color: Colors.white, width: 4)),
                          ),
                          const SizedBox(height: 8),
                          const Text("User#3",
                              style: TextStyle(color: Colors.grey))
                        ],
                      ),
                      Column(
                        children: [
                          Container(
                            height: 100,
                            width: 150,
                            decoration: BoxDecoration(
                                image: const DecorationImage(
                                  image: AssetImage("user.png"),
                                  fit: BoxFit.contain,
                                ),
                                shape: BoxShape.circle,
                                border:
                                    Border.all(color: Colors.white, width: 4)),
                          ),
                          const SizedBox(height: 8),
                          const Text("User#4",
                              style: TextStyle(color: Colors.grey))
                        ],
                      ),
                      Column(
                        children: [
                          Container(
                            height: 100,
                            width: 150,
                            decoration: BoxDecoration(
                                image: const DecorationImage(
                                  image: AssetImage("user.png"),
                                  fit: BoxFit.contain,
                                ),
                                shape: BoxShape.circle,
                                border:
                                    Border.all(color: Colors.white, width: 4)),
                          ),
                          const SizedBox(height: 8),
                          const Text("User#5",
                              style: TextStyle(color: Colors.grey))
                        ],
                      ),
                    ],
                  ),
                ),
                Center(
                  child: Container(
                      width: 350,
                      height: 30,
                      color: const Color.fromARGB(255, 77, 75, 75),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Padding(
                            padding: EdgeInsets.only(left: 4, right: 4),
                            child: Icon(
                              Icons.notifications_active,
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            "Notifications",
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 20),
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 170),
                            child: Icon(
                              Icons.arrow_forward_ios,
                              color: Colors.white,
                            ),
                          )
                        ],
                      )),
                ),
                const SizedBox(
                  height: 10,
                ),
                Center(
                  child: Container(
                      width: 350,
                      height: 30,
                      color: const Color.fromARGB(255, 77, 75, 75),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Padding(
                            padding: EdgeInsets.only(left: 4, right: 4),
                            child: Icon(
                              Icons.list_outlined,
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            "My List",
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 20),
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 220),
                            child: Icon(
                              Icons.arrow_forward_ios,
                              color: Colors.white,
                            ),
                          )
                        ],
                      )),
                ),
                const SizedBox(
                  height: 10,
                ),
                Center(
                  child: Container(
                      width: 350,
                      height: 30,
                      color: const Color.fromARGB(255, 77, 75, 75),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Padding(
                            padding: EdgeInsets.only(left: 4, right: 4),
                            child: Icon(
                              Icons.settings,
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            "App Settings",
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 20),
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 170),
                            child: Icon(
                              Icons.arrow_forward_ios,
                              color: Colors.white,
                            ),
                          )
                        ],
                      )),
                ),
                const SizedBox(
                  height: 10,
                ),
                Center(
                  child: Container(
                      width: 350,
                      height: 30,
                      color: const Color.fromARGB(255, 77, 75, 75),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Padding(
                            padding: EdgeInsets.only(left: 4, right: 4),
                            child: Icon(
                              Icons.account_circle_outlined,
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            "Account",
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 20),
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 210),
                            child: Icon(
                              Icons.arrow_forward_ios,
                              color: Colors.white,
                            ),
                          )
                        ],
                      )),
                ),
                const SizedBox(
                  height: 10,
                ),
                Center(
                  child: Container(
                      width: 350,
                      height: 30,
                      color: const Color.fromARGB(255, 77, 75, 75),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Padding(
                            padding: EdgeInsets.only(left: 4, right: 4),
                            child: Icon(
                              Icons.help,
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            "Help",
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 20),
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 240),
                            child: Icon(
                              Icons.arrow_forward_ios,
                              color: Colors.white,
                            ),
                          )
                        ],
                      )),
                ),
              ],
            )),
      ),
    );
  }
}
