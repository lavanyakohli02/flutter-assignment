import 'package:flutter/material.dart';
import 'package:netflixx/shared/widgets/indMov.dart';
import 'package:netflixx/shared/widgets/mylists.dart';
import 'package:netflixx/shared/widgets/nf_original.dart';
import 'package:netflixx/shared/widgets/nf_stack.dart';
import 'package:netflixx/shared/widgets/preview.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return const SingleChildScrollView(
      child: SizedBox(
          //color: Colors.black,
          width: double.infinity,
          //height: double.infinity,
          child: Column(
            children: [
              NFSTACK(),
              PREVIEW(),
              MyList(),
              NF_ORIGNAL(),
              IndMovie()
            ],
          )),
    );
  }
}
