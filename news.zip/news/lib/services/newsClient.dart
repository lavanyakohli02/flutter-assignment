import 'package:dio/dio.dart';

class NewsClient {
  final Dio _dio = Dio();

  getNewsDataFromAPI() async {
    String newsURL =
        "https://newsapi.org/v2/top-headlines?country=in&apiKey=d1592770a13f42329eba1aa2b07eded5";

    try {
      var resp = await _dio.get(newsURL);
      print("this is the news data ${resp.data}");
      return resp.data;
    } catch (error) {
      print("error in fetching data");
    }
  }
}
