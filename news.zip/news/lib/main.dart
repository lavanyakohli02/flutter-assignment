import 'package:flutter/material.dart';
import 'package:news/screens/homePage.dart';

void main() {
  runApp(const MaterialApp(home: HomePage()));
}
