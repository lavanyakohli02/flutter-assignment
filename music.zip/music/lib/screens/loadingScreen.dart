// // ignore_for_file: file_names
// import 'dart:async';
// import 'package:flutter/material.dart';
// // import 'package:muzic/screens/homeScreen.dart';

import 'dart:async';

import 'package:flutter/material.dart';

class LoadingScreen extends StatefulWidget {
  const LoadingScreen({super.key});

  @override
  State<LoadingScreen> createState() => _LoadingScreenState();
}

class _LoadingScreenState extends State<LoadingScreen> {
  bool isFirstLoadingScreenShow = true;
  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 2), () {
      isFirstLoadingScreenShow = false;
      setState(() {});

      if (isFirstLoadingScreenShow == false) {
        Timer(const Duration(seconds: 3), () {
          // Navigator.pushReplacement(
          //     context, MaterialPageRoute(builder: (_) => const HOMEPAGE()));
          Navigator.pushReplacementNamed(context, '/home');
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return isFirstLoadingScreenShow
        ? SafeArea(
            child: Scaffold(
            backgroundColor: const Color.fromARGB(31, 18, 18, 18),
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset("assets/amazon_music_logo_GIF.png"),
                  const CircularProgressIndicator(
                    color: Colors.white,
                  )
                ],
              ),
            ),
          ))
        : SafeArea(
            child: Scaffold(
            backgroundColor: const Color.fromARGB(31, 18, 18, 18),
            body: Center(
              child: Image.asset("assets/image3.png"),
            ),
          ));
  }
}
// class LoadingScreen extends StatefulWidget {
//   const LoadingScreen({super.key});

//   @override
//   State<LoadingScreen> createState() => _LoadingScreenState();
// }

// class _LoadingScreenState extends State<LoadingScreen> {
//   bool isFirstLoadingScreenShow = true;
//   @override
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//     Timer(const Duration(seconds: 3), () {
//       isFirstLoadingScreenShow = false;
//       setState(() {});
//       if (isFirstLoadingScreenShow == false) {
//         Timer(const Duration(seconds: 3), () {
//           // Navigator.pushReplacement(
//           //     context, MaterialPageRoute(builder: (_) => const HomePage()));

//           Navigator.pushReplacementNamed(context, '/home2');
//         });
//       }
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     return isFirstLoadingScreenShow
//         ? SafeArea(
//             child: Scaffold(
//             backgroundColor: Colors.black,
//             body: Center(
//               child: Column(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Image.asset(
//                     "assets/amazon_music_logo_GIF.png",
//                   ),
//                   const CircularProgressIndicator()
//                 ],
//               ),
//             ),
//           ))
//         : SafeArea(
//             child: Scaffold(
//             backgroundColor: Colors.black,
//             body: Center(
//               child: Image.asset(
//                 "assets/image3.png",
//               ),
//             ),
//           ));
//   }
// }


// // class LoadingScreen extends StatefulWidget {
// //   const LoadingScreen({super.key});

// //   @override
// //   State<LoadingScreen> createState() => _LoadingScreenState();
// // }

// // class _LoadingScreenState extends State<LoadingScreen> {
// //   bool isFirstLoadingScreenShow = true;
// //   @override
// //   void initState() {
// //     super.initState();
// //     Timer(const Duration(seconds: 3), () {
// //       isFirstLoadingScreenShow = false;
// //       setState(() {});
// //       if (isFirstLoadingScreenShow == false) {
// //         Timer(const Duration(seconds: 3), () {
// //           Navigator.pushReplacementNamed(context, '/home');
// //           //   Navigator.pushReplacement(
// //           //       context, MaterialPageRoute(builder: (_) => const HomePage()));
// //         });
// //       }
// //     });
// //   }

// //   @override
// //   Widget build(BuildContext context) {
// //     return isFirstLoadingScreenShow
// //         ? SafeArea(
// //             child: Scaffold(
// //                 body: Center(
// //                     child: Column(
// //             mainAxisAlignment: MainAxisAlignment.center,
// //             children: [
// //               Image.asset("assets/amazon_music_logo_GIF.png"),
// //               const CircularProgressIndicator(),
// //             ],
// //           ))))
// //         : SafeArea(
// //             child: Scaffold(
// //                 body: Center(
// //             child: Image.asset("assets/image3.png"),
// //           )));
// //   }
// // }
