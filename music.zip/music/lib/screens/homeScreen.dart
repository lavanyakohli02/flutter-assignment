// ignore_for_file: non_constant_identifier_names, file_names, avoid_unnecessary_containers

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:muzic/screens/player.dart';
import 'package:muzic/services/songClient.dart';
import 'package:muzic/services/songModel.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  SongClient songClient = SongClient();
  AudioPlayer audioPlayers = AudioPlayer();
  bool isSongPlaying = false;
  TextEditingController searchController = TextEditingController();

  late Future<List<songsModel>> _futureSongs;

  @override
  void initState() {
    super.initState();
    _futureSongs = _getSongsFromApi(searchQuery: searchController.text);
  }

  Future<List<songsModel>> _getSongsFromApi(
      {String searchQuery = 'ap dhillon'}) async {
    Map<String, dynamic> cMap =
        await songClient.getSongsFromITunes(searchQuery);
    List<dynamic> sList = cMap["results"];
    List<songsModel> finalSongList = toSongModel(sList);
    return finalSongList;
  }

  toSongModel(List<dynamic> list) {
    List<songsModel> convertedSongs = list.map((singleObject) {
      songsModel sModel = songsModel.fromJSON(singleObject);
      return sModel;
    }).toList();

    return convertedSongs;
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: Colors.white,
            appBar: AppBar(
              backgroundColor: Colors.white,
              leading: TextField(
                controller: searchController,
                onSubmitted: (value) {
                  setState(() {
                    print('Submitted $value ');

                    _getSongsFromApi(searchQuery: value);
                  });
                },
              ),
              // title: Text("Amazon Music"),
              // centerTitle: true,
            ),
            body: Container(
              child: FutureBuilder(
                  future: _getSongsFromApi(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(
                        child: CircularProgressIndicator(),
                      );
                    } else if (snapshot.hasError) {
                      return Center(
                        child: Text(
                            "some error has occured ${snapshot.error.toString()}"),
                      );
                    } else if (snapshot.hasData) {
                      return ListView.builder(
                          itemCount: snapshot.data!.length,
                          itemBuilder: (context, index) {
                            return Card(
                              elevation: 50,
                              color: const Color.fromARGB(255, 53, 52, 52),
                              child: ListTile(
                                onTap: () {
                                  Navigator.push(
                                      context,
                                      //       MaterialScreenRoute(
                                      //           builder: (_) => SongPlayer(
                                      //                 currentSongIndex: index,
                                      //                 fullList: snapshot.data!,
                                      //               )));
                                      // },
                                      MaterialPageRoute(
                                          builder: (_) => SongPlayer(
                                              artWorkUrl: snapshot
                                                  .data![index].artworkUrl100,
                                              artistName: snapshot
                                                  .data![index].artistName,
                                              previewUrl: snapshot
                                                  .data![index].previewUrl,
                                              trackName: snapshot
                                                  .data![index].trackName)));
                                },
                                leading: Image.network(
                                    snapshot.data![index].artworkUrl100),
                                title: Text(
                                  snapshot.data![index].trackName,
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold),
                                ),
                                subtitle: Text(
                                  snapshot.data![index].artistName,
                                  style: TextStyle(color: Colors.white),
                                ),
                                trailing: IconButton(
                                    onPressed: () async {
                                      isSongPlaying
                                          ? await audioPlayers.pause()
                                          : await audioPlayers.play(UrlSource(
                                              snapshot
                                                  .data![index].previewUrl));
                                      isSongPlaying = !isSongPlaying;
                                      snapshot.data![index].isPlaying =
                                          !snapshot.data![index].isPlaying;
                                      setState(() {}); //
                                    },
                                    icon: Icon((snapshot.data![index].isPlaying
                                        ? Icons.pause
                                        : Icons.play_arrow))),
                              ),
                            );
                          });
                    }
                    return const Placeholder();
                  }),
            )));
  }
}

// class HomeScreen extends StatefulWidget {
//   const HomeScreen({super.key});

//   @override
//   State<HomeScreen> createState() => _HomeScreenState();
// }

// class _HomeScreenState extends State<HomeScreen> {
//   SongClient songClient = SongClient();
//   AudioPlayer audioPlayers = AudioPlayer();
//   bool isSongPlaying = false;
//   TextEditingController searchController = TextEditingController();

//   late Future<List<SongModel>> _futureSongs;

//   @override
//   void initState() {
//     super.initState();
//     _futureSongs = _getSongsFromAPI(searchQuery: searchController.text);
//   }

//   Future<List<SongModel>> _getSongsFromAPI(
//       {String searchQuery = 'arijit singh'}) async {
//     Map<String, dynamic> cMap =
//         await songClient.getSongsFromITunes(searchQuery);
//     List<dynamic> sList = cMap['results'];
//     List<SongModel> finalSongList = toSongModel(sList);
//     return finalSongList;
//   }

//   toSongModel(List<dynamic> list) {
//     List<SongModel> convertedSongs = list.map((singleObject) {
//       SongModel sModel = SongModel.fromJSON(singleObject);
//       return sModel;
//     }).toList();
//     return convertedSongs;
//   }

//   @override
//   Widget build(BuildContext context) {
//     return SafeArea(
//         child: Scaffold(
//             appBar: AppBar(
//               // title: const Text("MUSIC APP"),
//               // centerTitle: true,
//               leading: TextField(
//                 controller: searchController,
//                 onSubmitted: (value) {
//                   setState(() {
//                     print('Submitted $value ');

//                     _getSongsFromAPI(searchQuery: value);
//                   });
//                 },
//               ),
//             ),
//             body: Container(
//                 child: FutureBuilder(
//                     future: _futureSongs,
//                     builder: (context, snapshot) {
//                       if (snapshot.connectionState == ConnectionState.waiting) {
//                         return const Center(
//                           child: CircularProgressIndicator(),
//                         );
//                       } else if (snapshot.hasError) {
//                         return Center(
//                           child: Text("Error : ${snapshot.error.toString()}"),
//                         );
//                       } else if (snapshot.hasData) {
//                         return ListView.builder(
//                             itemCount: snapshot.data!.length,
//                             itemBuilder: (context, index) {
//                               return ListTile(
//                                   onTap: () {
//                                     Navigator.push(
//                                         context,
//                                         MaterialScreenRoute(
//                                             builder: (_) => SongPlayer(
//                                                   currentSongIndex: index,
//                                                   fullList: snapshot.data!,
//                                                 )));
//                                     // SongPlayer(
//                                     //       artWorkUrl: snapshot
//                                     //           .data![index]
//                                     //           .artworkUrl100,
//                                     //       artistName: snapshot
//                                     //           .data![index].artistName,
//                                     //       previewUrl: snapshot
//                                     //           .data![index].previewUrl,
//                                     //       trackName: snapshot
//                                     //           .data![index].trackName,
//                                     //       currentStat: snapshot
//                                     //           .data![index].isPlaying,
//                                     //     )));
//                                   },
//                                   leading: Image.network(
//                                       snapshot.data![index].artworkUrl100),
//                                   title: Text(snapshot.data![index].trackName),
//                                   subtitle:
//                                       Text(snapshot.data![index].artistName),
//                                   trailing: IconButton(
//                                       onPressed: () async {
//                                         isSongPlaying
//                                             ? await audioPlayers.pause()
//                                             : await audioPlayers.play(UrlSource(
//                                                 snapshot
//                                                     .data![index].previewUrl));
//                                         isSongPlaying = !isSongPlaying;
//                                         snapshot.data![index].isPlaying =
//                                             !snapshot.data![index].isPlaying;
//                                         setState(() {}); //widget tree rebuild
//                                       },
//                                       icon: Icon(
//                                           (snapshot.data![index].isPlaying
//                                               ? Icons.pause
//                                               : Icons.play_arrow))));
//                             });
//                         // return const Center(
//                         //   child: Text("SUCCESS"),
//                         // );
//                       }
//                       return const Placeholder();
//                     }))));
//   }
// }






// class HomeScreen extends StatefulWidget {
//   const HomeScreen({super.key});

//   @override
//   State<HomeScreen> createState() => _HomeScreenState();
// }

// class _HomeScreenState extends State<HomeScreen> {
//   SongClient songClient = SongClient();
//   AudioPlayer audioPlayers = AudioPlayer();
//   bool isSongPlaying = false;
//   TextEditingController searchController = TextEditingController();

//   late Future<List<SongModel>> _futureSongs;

//   @override
//   void initState() {
//     super.initState();
//     _futureSongs = _getSongsFromAPI();
//   }

//   Future<List<SongModel>> _getSongsFromAPI(
//       {String searchQuery = 'arijit singh'}) async {
//     Map<String, dynamic> cMap = await songClient.getSongsFromITunes();
//     List<dynamic> sList = cMap['results'];
//     List<SongModel> finalSongList = toSongModel(sList);
//     return finalSongList;
//   }

//   toSongModel(List<dynamic> list) {
//     List<SongModel> convertedSongs = list.map((singleObject) {
//       SongModel sModel = SongModel.fromJSON(singleObject);
//       return sModel;
//     }).toList();
//     return convertedSongs;
//   }

//   @override
//   Widget build(BuildContext context) {
//     return SafeArea(
//         child: Scaffold(
//             appBar: AppBar(
//               // title: const Text("MUSIC APP"),
//               // centerTitle: true,
//               leading: TextField(
//                 controller: searchController,
//                 onSubmitted: (value) {
//                   setState(() {
//                     print('Submitted $value ');

//                     _getSongsFromAPI(searchQuery: value);
//                   });
//                 },
//               ),
//             ),
//             body: Container(
//                 child: FutureBuilder(
//                     future: _futureSongs,
//                     builder: (context, snapshot) {
//                       if (snapshot.connectionState == ConnectionState.waiting) {
//                         return const Center(
//                           child: CircularProgressIndicator(),
//                         );
//                       } else if (snapshot.hasError) {
//                         return Center(
//                           child: Text("Error : ${snapshot.error.toString()}"),
//                         );
//                       } else if (snapshot.hasData) {
//                         return ListView.builder(
//                             itemCount: snapshot.data!.length,
//                             itemBuilder: (context, index) {
//                               return ListTile(
//                                   onTap: () {
//                                     Navigator.push(
//                                         context,
//                                         MaterialScreenRoute(
//                                             builder: (_) => SongPlayer(
//                                                 artWorkUrl: snapshot
//                                                     .data![index].artworkUrl100,
//                                                 artistName: snapshot
//                                                     .data![index].artistName,
//                                                 previewUrl: snapshot
//                                                     .data![index].previewUrl,
//                                                 trackName: snapshot
//                                                     .data![index].trackName)));
//                                   },
//                                   leading: Image.network(
//                                       snapshot.data![index].artworkUrl100),
//                                   title: Text(snapshot.data![index].trackName),
//                                   subtitle:
//                                       Text(snapshot.data![index].artistName),
//                                   trailing: IconButton(
//                                       onPressed: () async {
//                                         isSongPlaying
//                                             ? await audioPlayers.pause()
//                                             : await audioPlayers.play(UrlSource(
//                                                 snapshot
//                                                     .data![index].previewUrl));
//                                         isSongPlaying = !isSongPlaying;
//                                         snapshot.data![index].isPlaying =
//                                             !snapshot.data![index].isPlaying;
//                                         setState(() {}); //widget tree rebuild
//                                       },
//                                       icon: Icon(
//                                           (snapshot.data![index].isPlaying
//                                               ? Icons.pause
//                                               : Icons.play_arrow))));
//                             });
//                         // return const Center(
//                         //   child: Text("SUCCESS"),
//                         // );
//                       }
//                       return const Placeholder();
//                     }))));
//   }
// }


// import 'package:audioplayers/audioplayers.dart';
// import 'package:flutter/material.dart';
// import 'package:muzic/screens/player.dart';
// import 'package:muzic/services/songClient.dart';
// import 'package:muzic/services/songModel.dart';

// class HomeScreen extends StatefulWidget {
//   const HomeScreen({super.key});

//   @override
//   State<HomeScreen> createState() => _HomeScreenState();
// }

// class _HomeScreenState extends State<HomeScreen> {
//   SongClient songClient = SongClient();
//   AudioPlayer audioPlayers = AudioPlayer();
//   bool isSongPlaying = false;

//   late Future<List<SongModel>> _futureSongs;

//   @override
//   void initState() {
//     super.initState();
//     _futureSongs = _getSongsFromAPI();
//   }

//   Future<List<SongModel>> _getSongsFromAPI() async {
//     Map<String, dynamic> cMap = await songClient.getSongsFromITunes();
//     List<dynamic> sList = cMap['results'];
//     List<SongModel> finalSongList = toSongModel(sList);
//     return finalSongList;
//   }

//   toSongModel(List<dynamic> list) {
//     List<SongModel> convertedSongs = list.map((singleObject) {
//       SongModel sModel = SongModel.fromJSON(singleObject);
//       return sModel;
//     }).toList();
//     return convertedSongs;
//   }

//   @override
//   Widget build(BuildContext context) {
//     return SafeArea(
//         child: Scaffold(
//             appBar: AppBar(
//               title: const Text("MUZIC"),
//               centerTitle: true,
//             ),
//             // appBar: AppBar(),
//             body: Container(
//                 child: FutureBuilder(
//                     future: _getSongsFromAPI(),
//                     builder: (context, snapshot) {
//                       if (snapshot.connectionState == ConnectionState.waiting) {
//                         return const Center(
//                           child: CircularProgressIndicator(),
//                         );
//                       } else if (snapshot.hasError) {
//                         return Center(
//                             child: Text("error: ${snapshot.error.toString()}"));
//                       } else if (snapshot.hasData) {
//                         return ListView.builder(
//                             itemCount: snapshot.data!.length,
//                             itemBuilder: (context, index) {
//                               return ListTile(
//                                 onTap: () {
//                                   Navigator.push(
//                                       context,
//                                       MaterialScreenRoute(
//                                           builder: (_) => SongPlayer(
//                                               artWorkUrl: snapshot
//                                                   .data![index].artworkUrl100,
//                                               artistName: snapshot
//                                                   .data![index].artistName,
//                                               previewUrl: snapshot
//                                                   .data![index].previewUrl,
//                                               trackName: snapshot
//                                                   .data![index].trackName)));
//                                 },
//                                 leading: Image.network(
//                                     snapshot.data![index].artworkUrl100),
//                                 title: Text(snapshot.data![index].trackName),
//                                 subtitle:
//                                     Text(snapshot.data![index].artistName),
//                                 trailing: IconButton(
//                                     onPressed: () {
//                                       isSongPlaying
//                                           ? audioPlayers.play(UrlSource(
//                                               snapshot.data![index].previewUrl))
//                                           : audioPlayers.pause();
//                                       isSongPlaying = !isSongPlaying;
//                                       setState(() {});
//                                     },
//                                     icon: isSongPlaying
//                                         ? const Icon(Icons.pause)
//                                         : const Icon(Icons.play_arrow)),
//                               );
//                             });
//                         // return const Center(
//                         //   child: Text('SUCCESS'),
//                         // );
//                       }
//                       return const Placeholder();
//                     }))));
//   }
// }




// import 'package:audioplayers/audioplayers.dart';
// import 'package:flutter/material.dart';
// import 'package:sangeet_music/screens/player.dart';
// import 'package:sangeet_music/services/songClient.dart';
// import 'package:sangeet_music/services/songModel.dart';

// class HomeScreen extends StatefulWidget {
//   const HomeScreen({super.key});

//   @override
//   State<HomeScreen> createState() => _HomeScreenState();
// }

// class _HomeScreenState extends State<HomeScreen> {
//   SongClient songClient = SongClient();
//   AudioPlayer audioPlayers = AudioPlayer();
//   bool isSongPlaying = false;
//   Future<List<SongModel>> _getSongsFromAPI() async {
  //   Map<String, dynamic> cMap = await songClient.getSongsFromITunes();
  //   List<dynamic> sList = cMap['results'];
  //   List<SongModel> finalSongList = toSongModel(sList);
  //   return finalSongList;
  // }

  // toSongModel(List<dynamic> list) {
  //   List<SongModel> convertedSongs = list.map((singleObject) {
  //     SongModel sModel = SongModel.fromJSON(singleObject);
  //     return sModel;
  //   }).toList();
  //   return convertedSongs;
  // }

  // @override
  // Widget build(BuildContext context) {
  //   return SafeArea(
  //       child: Scaffold(
  //           appBar: AppBar(
  //             title: const Text("MUSIC APP"),
  //             centerTitle: true,
  //           ),
  //           body: Container(
  //               child: FutureBuilder(
  //                   future: _getSongsFromAPI(),
//                     builder: (context, snapshot) {
//                       if (snapshot.connectionState == ConnectionState.waiting) {
//                         return const Center(
//                           child: CircularProgressIndicator(),
//                         );
//                       } else if (snapshot.hasError) {
//                         return Center(
//                           child: Text("Error : ${snapshot.error.toString()}"),
//                         );
//                       } else if (snapshot.hasData) {
//                         return ListView.builder(
//                             itemCount: snapshot.data!.length,
//                             itemBuilder: (context, index) {
//                               return ListTile(
//                                 onTap: () {
//                                   Navigator.push(
//                                       context,
//                                       MaterialScreenRoute(
//                                           builder: (_) => SongPlayer(
//                                               artWorkUrl: snapshot
//                                                   .data![index].artworkUrl100,
//                                               artistName: snapshot
//                                                   .data![index].artistName,
//                                               previewUrl: snapshot
//                                                   .data![index].previewUrl,
//                                               trackName: snapshot
//                                                   .data![index].trackName)));
//                                 },
//                                 leading: Image.network(
//                                     snapshot.data![index].artworkUrl100),
//                                 title: Text(snapshot.data![index].trackName),
//                                 subtitle:
//                                     Text(snapshot.data![index].artistName),
//                                 trailing: IconButton(
//                                     onPressed: () {
//                                       isSongPlaying
//                                           ? audioPlayers.play(UrlSource(
//                                               snapshot.data![index].previewUrl))
//                                           : audioPlayers.pause();
//                                       isSongPlaying = !isSongPlaying;
//                                       setState(() {});
//                                     },
//                                     icon: isSongPlaying
//                                         ? const Icon(Icons.pause)
//                                         : const Icon(Icons.play_arrow)),
//                               );
//                             });
//                         // return const Center(
//                         //   child: Text("SUCCESS"),
//                         // );
//                       }
//                       return const Placeholder();
//                     }))));
//   }
// }



// Column(
//       mainAxisAlignment: MainAxisAlignment.center,
//       children: [
//         const Center(
//           child: Text("homeScreen"),
//         ),
//         Center(
//           child: IconButton(
//               onPressed: () {
//                 songClient.getSongsFromITunes();
//               },
//               icon: const Icon(Icons.get_app)),
//         ),
//       ],
//     )

// import 'package:flutter/material.dart';
// import 'package:sangeet_music/services/songClient.dart';
// import 'package:sangeet_music/services/songModel.dart';

// class HomeScreen extends StatefulWidget {
//   const HomeScreen({super.key});

//   @override
//   State<HomeScreen> createState() => _HomeScreenState();
// }

// class _HomeScreenState extends State<HomeScreen> {
//   SongClient songClient = SongClient();

//   Future<List<SongModel>> _getSongsFromAPI() async {
//     Map<String, dynamic> cMap = await songClient.getSongsFromITunes();
//     List<dynamic> sList = cMap['results'];
//     List<SongModel> finalSongList = toSongModel(sList);
//     return finalSongList;
//   }

//   toSongModel(List<dynamic> list) {
//     List<SongModel> convertedSongs = list.map((singleObject) {
//       SongModel sModel = SongModel.fromJSON(singleObject);
//       return sModel;
//     }).toList();
//     return convertedSongs;
//   }

//   @override
//   Widget build(BuildContext context) {
//     return SafeArea(
//         child: Scaffold(
//             appBar: AppBar(
//               title: const Text("MUSIC APP"),
//               centerTitle: true,
//             ),
//             body: Container(
//                 child: FutureBuilder(
//                     future: _getSongsFromAPI(),
//                     builder: (context, snapshot) {
//                       if (snapshot.connectionState == ConnectionState.waiting) {
//                         return const Center(
//                           child: CircularProgressIndicator(),
//                         );
//                       } else if (snapshot.hasError) {
//                         return Center(
//                           child: Text("Error : ${snapshot.error.toString()}"),
//                         );
//                       } else if (snapshot.hasData) {
//                         return ListView.builder(
//                             itemCount: snapshot.data!.length,
//                             itemBuilder: (context, index) {
//                               return ListTile(
//                                 leading: Image.network(
//                                     snapshot.data![index].artworkUrl100),
//                                 title: Text(snapshot.data![index].trackName),
//                                 subtitle:
//                                     Text(snapshot.data![index].artistName),
//                                 trailing: IconButton(
//                                     onPressed: () {},
//                                     icon: const Icon(Icons.play_arrow)),
//                               );
//                             });
//                         // return const Center(
//                         //   child: Text("SUCCESS"),
//                         // );
//                       }
//                       return const Placeholder();
//                     }))));
//   }
// }


// Future<List<SongModel>> _getSongsFromAPI() async {
//     Map<String, dynamic> cMap = await songClient.getSongsFromITunes();
//     List<dynamic> sList = cMap['results'];
//     List<SongModel> finalSongList = toSongModel(sList);
//     return finalSongList;
//   }

//   toSongModel(List<dynamic> list) {
//     List<SongModel> convertedSongs = list.map((singleObject) {
//       SongModel sModel = SongModel.fromJSON(singleObject);
//       return sModel;
//     }).toList();
//     return convertedSongs;
//   }


// import 'package:audioplayers/audioplayers.dart';
// import 'package:flutter/material.dart';
// import 'package:sangeet_music/services/songClient.dart';
// import 'package:sangeet_music/services/songModel.dart';

// class HomeScreen extends StatefulWidget {
//   const HomeScreen({super.key});

//   @override
//   State<HomeScreen> createState() => _HomeScreenState();
// }

// class _HomeScreenState extends State<HomeScreen> {
//   SongClient songClient = SongClient();
//   AudioPlayer audioPlayers = AudioPlayer();
//   bool isSongPlaying = false;
//   Future<List<SongModel>> _getSongsFromAPI() async {
//     Map<String, dynamic> cMap = await songClient.getSongsFromITunes();
//     List<dynamic> sList = cMap['results'];
//     List<SongModel> finalSongList = toSongModel(sList);
//     return finalSongList;
//   }

//   toSongModel(List<dynamic> list) {
//     List<SongModel> convertedSongs = list.map((singleObject) {
//       SongModel sModel = SongModel.fromJSON(singleObject);
//       return sModel;
//     }).toList();
//     return convertedSongs;
//   }

//   @override
//   Widget build(BuildContext context) {
//     return SafeArea(
//         child: Scaffold(
//             appBar: AppBar(
//               title: const Text("MUSIC APP"),
//               centerTitle: true,
//             ),
//             body: Container(
//                 child: FutureBuilder(
//                     future: _getSongsFromAPI(),
//                     builder: (context, snapshot) {
//                       if (snapshot.connectionState == ConnectionState.waiting) {
//                         return const Center(
//                           child: CircularProgressIndicator(),
//                         );
//                       } else if (snapshot.hasError) {
//                         return Center(
//                           child: Text("Error : ${snapshot.error.toString()}"),
//                         );
//                       } else if (snapshot.hasData) {
//                         return ListView.builder(
//                             itemCount: snapshot.data!.length,
//                             itemBuilder: (context, index) {
//                               return ListTile(
//                                 leading: Image.network(
//                                     snapshot.data![index].artworkUrl100),
//                                 title: Text(snapshot.data![index].trackName),
//                                 subtitle:
//                                     Text(snapshot.data![index].artistName),
//                                 trailing: IconButton(
//                                     onPressed: () {
//                                       isSongPlaying
//                                           ? audioPlayers.play(UrlSource(
//                                               snapshot.data![index].previewUrl))
//                                           : audioPlayers.pause();
//                                       isSongPlaying = !isSongPlaying;
//                                       setState(() {});
//                                     },
//                                     icon: isSongPlaying
//                                         ? const Icon(Icons.pause)
//                                         : const Icon(Icons.play_arrow)),
//                               );
//                             });
//                         // return const Center(
//                         //   child: Text("SUCCESS"),
//                         // );
//                       }
//                       return const Placeholder();
//                     }))));
//   }
// }
