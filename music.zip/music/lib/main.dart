import 'package:flutter/material.dart';
import 'package:muzic/screens/homePage.dart';
import 'package:muzic/screens/homeScreen.dart';
import 'package:muzic/screens/loadingScreen.dart';

void main() {
  runApp(MaterialApp(
    // home: LOADINGSCREEN(),
    theme: ThemeData.dark(),
    initialRoute: '/',
    routes: {
      '/': (context) => const LoadingScreen(),
      '/home': (context) => const HomeScreen(),
      '/home2': (context) => const HomePage2(),
    },
  ));
}
