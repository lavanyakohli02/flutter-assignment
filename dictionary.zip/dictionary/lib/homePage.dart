// ignore_for_file: file_names

import 'package:dict/service/dictClient.dart';
import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  DictClient dClient = DictClient();
  TextEditingController tc = TextEditingController();
  String meaning = "null";
  //String m = null;
  // @override
  // void initState(){
  //   //TODO: implement initState() //////////////// IMP
  //   super.initState();
  // }

  callAPI(q) async {
    await dClient.searchForWord(query: q);
    meaning = await dClient.searchForWord(query: q);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: const Text(
          "DICTIONARY",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(18.0),
        child: SizedBox(
          // color: Colors.teal,
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          child: Column(
            children: [
              TextField(
                controller: tc,
                decoration: InputDecoration(
                    border: const OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(50))),
                    suffixIcon: IconButton(
                        onPressed: () {}, icon: const Icon(Icons.clear)),
                    label: const Text("dictionary"),
                    hintText: "enter a word to search"),
                // style: ,
                keyboardType: TextInputType.number,
                onChanged: (string) {
                  // print(textfield.text); //controller--> text
                  print("This is the text from the textfield $string");
                },
                onEditingComplete: () {
                  // print(
                  //     // "this is the final submission from the textfield ${txtfld.text}");
                },
              ),
              Padding(
                padding: const EdgeInsets.all(18.0),
                child: OutlinedButton(
                    onPressed: () {
                      callAPI(tc.text);
                    },
                    child: const Icon(Icons.search)),
              ),
              Container(
                color: Color.fromARGB(255, 156, 210, 255),
                width: 300,
                height: 300,
                child: Center(
                    child: Text(meaning,
                        style: const TextStyle(
                            fontSize: 15, fontWeight: FontWeight.bold))),
              )
            ],
          ),
        ),
      ),
    ));
  }
}


// import 'package:flutter/material.dart';

// class HomePage extends StatefulWidget {
//   const HomePage({super.key});

//   @override
//   State<HomePage> createState() => _HomePageState();
// }

// class _HomePageState extends State<HomePage> {
//   @override
//   Widget build(BuildContext context) {
//     return SafeArea(
//         child: Scaffold(
//       appBar: AppBar(
//         title: const Text("DICTIONARY"),
//         centerTitle: true,
//       ),
//       body: SizedBox(
//         // color: Colors.teal,
//         height: MediaQuery.of(context).size.height,
//         width: MediaQuery.of(context).size.width,
//         child: Column(
//           children: [
//             TextField(
//               controller: tc,
//               decoration: InputDecoration(
//                   border: const OutlineInputBorder(
//                       borderRadius: BorderRadius.all(Radius.circular(50))),
//                   suffixIcon: IconButton(
//                       onPressed: () {}, icon: const Icon(Icons.clear)),
//                   label: const Text("DICT"),
//                   hintText: "Enter a Word Here"),
//               // style: ,
//               keyboardType: TextInputType.number,
//               onChanged: (string) {
//                 // print(textfield.text); //controller--> text
//                 print("This is the text from the textfield $string");
//               },
//               onEditingComplete: () {
//                 // print(
//                 //     // "this is the final submission from the textfield ${txtfld.text}");
//               },
//             ),
//             OutlinedButton(
//               style:
//               onPressed: () {
//                 _callAPI(tc.text);
//               },

//               _callAPI(q) async

//               child: const Text("SEARCH")),
//               Container(
//                 color: Colors.amber,
//                 width: MediaQuery.of(context).size.width,
//                 height: MediaQuery.of(context).size.height * 0.15,
//                 child: Center(
//                   child: Text(
//                     meaning,
//                     style: const TextStyle(fontSize: 20),
//                   )
//                   ),
//                 )
//           ],
//         ),
//       ),
//     ));
//   }
// }
