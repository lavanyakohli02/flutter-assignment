import 'package:dict/homePage.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(
    home: HomePage(),
  ));
}


// import 'package:dict/homePage.dart';
// import 'package:flutter/material.dart';

// void main() {
//   runApp(const MaterialApp(home: HomePage()));
// }
