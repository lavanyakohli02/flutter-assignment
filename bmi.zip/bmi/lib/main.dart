import 'package:bmi/screenn/firstPage.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(home: FirstPage()));
}
