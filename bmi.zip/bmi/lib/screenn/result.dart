// ignore_for_file: must_be_immutable, non_constant_identifier_names

import 'package:bmi/screenn/firstPage.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class RESULTPAGE extends StatelessWidget {
  double BMIVALUE = 0;
  RESULTPAGE({super.key, required this.BMIVALUE});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                "YOUR BMI IS",
                style: TextStyle(color: Colors.white, fontSize: 25),
              ),
              Text(
                "BMI: ${BMIVALUE.toString().substring(0, 5)} kg/m2 (${getBMIStatus(BMIVALUE)})",
                style: const TextStyle(color: Colors.white, fontSize: 25),
              ),
              Text('heyy',
                  style:
                      GoogleFonts.pacifico(fontSize: 20, color: Colors.white)),
            ],
          ),
        ),
      ),
    );
  }
}


// body: Container(
//   child: Center(
//     child: Column(
//       mainAxisAlignment: MainAxisAlignment.center,
//       children: [
//         TextField(
//           controller: textfield,
//           obsecureText: true,
//           decoration: InputDecoration(

//           ),
//         )
//       ])
//     ,)
// )