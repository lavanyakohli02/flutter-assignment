// ignore_for_file: file_names, sized_box_for_whitespace

import 'package:bmi/screenn/result.dart';
import 'package:flutter/material.dart';

class FirstPage extends StatefulWidget {
  const FirstPage({super.key});

  @override
  State<FirstPage> createState() => _FirstPageState();
}

calcBMI({double height = 0.0, double weight = 0.0}) {
  height = height / 100;
  double bmiValue =
      (weight / (height * height)); //weight in KG and height in meter
  return bmiValue;
}

String getBMIStatus(double bmiValue) {
  if (bmiValue < 18.5) {
    return 'underweight';
  } else if (bmiValue >= 18.5 && bmiValue < 25) {
    return 'normal';
  } else {
    return 'overweight';
  }
}

class _FirstPageState extends State<FirstPage> {
  double sliderValue = 100.0;
  double weightval = 0.00;
  int age = 0;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: Colors.black,
            appBar: AppBar(
                title: const Text('BMI CALCULATOR'),
                titleTextStyle: const TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.bold),
                centerTitle: true,
                backgroundColor: Color.fromARGB(255, 56, 56, 56)),
            body: Column(children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Container(
                    // color: Colors.blue,
                    width: MediaQuery.of(context).size.width * 0.4,
                    height: MediaQuery.of(context).size.height * 0.3,
                    child: const Column(children: [
                      Icon(
                        Icons.male,
                        size: 100,
                        color: Color.fromARGB(255, 0, 157, 255),
                      ),
                      Text(
                        "MALE",
                        style: TextStyle(color: Colors.white, fontSize: 30),
                      ),
                    ]),
                  ),
                  Container(
                    // color: Colors.blue,
                    width: MediaQuery.of(context).size.width * 0.4,
                    height: MediaQuery.of(context).size.height * 0.3,
                    child: const Column(
                      children: [
                        Icon(
                          Icons.female,
                          size: 100,
                          color: Color.fromARGB(255, 255, 0, 230),
                        ),
                        Text(
                          "FEMALE",
                          style: TextStyle(color: Colors.white, fontSize: 30),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height * 0.02,
              ),
              Container(
                  // color: Colors.purple,
                  width: MediaQuery.of(context).size.width * 0.4,
                  height: MediaQuery.of(context).size.height * 0.2,
                  child: Column(children: [
                    Slider(
                        min: 100,
                        max: 250,
                        value: sliderValue,
                        onChanged: (value) {
                          sliderValue = value;
                          setState(() {});
                        },
                        activeColor: const Color.fromARGB(255, 255, 98, 98),
                        inactiveColor: Color.fromARGB(255, 255, 235, 235)),
                    Text('${sliderValue.toStringAsFixed(2)} cm',
                        style:
                            const TextStyle(color: Colors.white, fontSize: 30)),
                    const Text(
                      'HEIGHT',
                      style: TextStyle(color: Colors.white, fontSize: 30),
                    ),
                  ])),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Container(
                    // color: Colors.black,
                    width: MediaQuery.of(context).size.width * 0.4,
                    height: MediaQuery.of(context).size.height * 0.2,
                    child: Column(children: [
                      const Text(
                        'WEIGHT',
                        style: TextStyle(color: Colors.white, fontSize: 30),
                      ),
                      Text(weightval.toStringAsFixed(2),
                          style: const TextStyle(
                              color: Colors.white, fontSize: 30)),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          CircleAvatar(
                              backgroundColor:
                                  Color.fromARGB(255, 222, 225, 227),
                              child: IconButton(
                                  onPressed: () {
                                    weightval--;
                                    setState(() {});
                                  },
                                  icon: const Icon(Icons.remove))),
                          CircleAvatar(
                              backgroundColor:
                                  Color.fromARGB(255, 222, 225, 227),
                              child: IconButton(
                                  onPressed: () {
                                    weightval++;
                                    setState(() {});
                                  },
                                  icon: const Icon(Icons.add)))
                        ],
                      )
                    ]),
                  ),
                  Container(
                    // color: Colors.black,
                    width: MediaQuery.of(context).size.width * 0.4,
                    height: MediaQuery.of(context).size.height * 0.2,
                    child: Column(
                      children: [
                        const Text(
                          'AGE',
                          style: TextStyle(color: Colors.white, fontSize: 30),
                        ),
                        Text(age.toStringAsFixed(0),
                            style: const TextStyle(
                                color: Colors.white, fontSize: 30)),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            CircleAvatar(
                                backgroundColor:
                                    Color.fromARGB(255, 222, 225, 227),
                                child: IconButton(
                                    onPressed: () {
                                      age--;
                                      setState(() {});
                                    },
                                    icon: const Icon(Icons.remove))),
                            CircleAvatar(
                                backgroundColor:
                                    Color.fromARGB(255, 222, 225, 227),
                                child: IconButton(
                                    onPressed: () {
                                      age++;
                                      setState(() {});
                                    },
                                    icon: const Icon(Icons.add)))
                          ],
                        )
                      ],
                    ),
                  ),
                ],
              ),
              SizedBox(
                // height: 20,
                height: MediaQuery.of(context).size.height * 0.02,
              ),
              GestureDetector(
                onTap: () {
                  double finalBMI =
                      calcBMI(height: sliderValue, weight: weightval);
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => RESULTPAGE(
                                BMIVALUE: finalBMI,
                              )));
                },
                child: Container(
                  // color: Colors.yellow,
                  width: MediaQuery.of(context).size.width * 0.8,
                  height: MediaQuery.of(context).size.height * 0.1,
                  child: const Center(
                    child: Text(
                      "CALCULATE BMI",
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 40,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              )
            ])));
  }
}
